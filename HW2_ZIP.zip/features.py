# -*- coding: utf-8 -*-
"""
Created on Mon Jun  6 14:00:51 2022

@author: ravim
"""
import re

def test_features(sentence, i, history):
    """Chunker features designed to test the Chunker class for correctness 
        - the POS tag of the word
        - the entire history of IOB tags so far
            formatted as a tuple because it needs to be hashable
    """ 
    # tfd = test_features_dict
    tfd = dict()
    word, pos = sentence[i]
    tfd["pos"] = pos
    tfd["whole history"] = tuple(history)
    
    if re.search(r"A-Z", word[0]):
        tfd["Capital"] = word.lower()
        
    if re.search(r"q|Q", word):
        tfd["Contains-Q"] = word.lower()
    
    if re.search(r"x|X", word):
        tfd["Contains-X"] = word.lower()   
        
    if re.search(r"a|A", word):
        tfd["Contains-A"] = word.lower()
        
    if re.search(r"e|E", word):
        tfd["Contains-E"] = word.lower()
        
    return tfd

def tag_features(sentence, i, history):
    
    tagdict = dict()
    word, pos = sentence[i]
    tagdict["pos"] = pos
    tagdict["whole history"] = tuple(history)
    
    if i > 0:
        tagdict["preceding tag"] = history[i-1]
    
        if history[i-1] == 'N':
            tagdict["N"] = word.lower()
            
        if history[i-1] == 'Art':
            tagdict["Art"] = word.lower()
        
        if history[i-1] == 'V':
            tagdict["V"] = word.lower()
    
    
    return tagdict
    
        
def length_features(sentence, i, history):
    ldict = dict()
    word, pos = sentence[i]
    ldict["pos"] = pos
    ldict["whole history"] = tuple(history)
    
    if len(word) < 5:
        ldict["short-word"] = word.lower()
    
    if len(word) > 5 and len(word) < 10:
        ldict["long-word"] = word.lower()
        
    if len(word) > 10 and len(word) < 20:
        ldict["very long word"] = word.lower()
        
    if len(word) > 20:
        ldict["extremely long word"] = word.lower()
        
    return ldict