# -*- coding: utf-8 -*-


import pickle
import sys

path = sys.argv[1]
modelname = sys.argv[2]

ner = pickle.load(open(path, "rb")) # loading our stored model

from nltk.corpus import conll2002 as conll

# Usage 2: self-evaluate (on chunked sentences)
chunkzinnen = conll.chunked_sents("ned.testa")[1000:1500]
print("Model:", modelname)
print(ner.evaluate(chunkzinnen))