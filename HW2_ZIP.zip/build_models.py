# -*- coding: utf-8 -*-
"Made by: Ravi Moelchand - 7463332, Casper Bruning - 6590802, Yannick Usabuwera - 7309368"
from custom_chunker import ConsecutiveNPChunker
import features as ft
from nltk.corpus import conll2002 as conll
import pickle
import sys
 
args = sys.argv[1:] 
path = args[0]
modelname = args[1] 

if args[2] == "test_features":                  # selecting the right feature function to use
    feature_set = ft.test_features
elif args[2] == "tag_features":
    feature_set = ft.tag_features
elif args[2] == "length_features":
    feature_set = ft.length_features
else:
    raise ValueError("Choose correct feature set: 'test_features', 'tag_features' or 'length_features'")
    
    
cmd_algorithm = args[3]

training = conll.chunked_sents("ned.train") # training sentences
recognizer = ConsecutiveNPChunker(feature_set, training, algorithm=cmd_algorithm) # building the model

output = open(path, "wb")
pickle.dump(recognizer, output)
output.close() # storing our freshly made model